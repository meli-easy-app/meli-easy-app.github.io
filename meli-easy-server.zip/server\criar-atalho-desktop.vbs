' Cria atalho do Meli Easy Server na area de trabalho
Set oWS = WScript.CreateObject("WScript.Shell")
Dim sLinkFile
sLinkFile = oWS.SpecialFolders("Desktop") & "\Meli Easy Server.lnk"

Set oLink = oWS.CreateShortcut(sLinkFile)
oLink.TargetPath = WScript.ScriptFullName
oLink.TargetPath = Left(WScript.ScriptFullName, InStrRev(WScript.ScriptFullName, "\")) & "iniciar.bat"
oLink.WorkingDirectory = Left(WScript.ScriptFullName, InStrRev(WScript.ScriptFullName, "\") - 1)
oLink.Description = "Inicia o servidor Meli Easy e abre o app"
oLink.IconLocation = "shell32.dll,21"
oLink.Save

MsgBox "Atalho criado na area de trabalho!" & Chr(13) & "Use 'Meli Easy Server' para iniciar o servidor e o app.", 64, "Meli Easy"
