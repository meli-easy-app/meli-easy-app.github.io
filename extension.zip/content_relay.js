// Bridge: web page (postMessage) <-> extension background (chrome.runtime)
window.addEventListener('message', function(event) {
  if (event.source !== window || !event.data || !event.data.__meliEasy) return;
  try {
    chrome.runtime.sendMessage(event.data, function(response) {
      if (chrome.runtime.lastError) return;
      if (response) window.postMessage(Object.assign({}, response, { __meliEasyResp: true }), '*');
    });
  } catch(e) {}
});

// Forward push messages from background to the page
chrome.runtime.onMessage.addListener(function(msg, sender, sendResponse) {
  if (msg && msg.__meliEasyPush) {
    window.postMessage(msg, '*');
    sendResponse({ ok: true });
  }
  return true;
});

// Announce presence to the page
window.postMessage({ __meliEasyReady: true }, '*');