@echo off
title Meli Easy Server
echo.
echo  =========================================
echo   Meli Easy Server - iniciando...
echo  =========================================
echo.
cd /d "%~dp0"

:: Verifica se node esta instalado
where node >nul 2>&1
if errorlevel 1 (
  echo  ERRO: Node.js nao encontrado.
  echo  Baixe em: https://nodejs.org  ^(versao 18 ou superior^)
  pause
  exit /b 1
)

:: Instala dependencias na primeira vez
if not exist "node_modules\puppeteer-core" (
  echo  Instalando dependencias pela primeira vez ^(pode demorar 1-2 min^)...
  call npm install
  echo.
)

:: Abre o site no navegador padrao
echo  Abrindo o app...
start "" "https://meli-easy-app.github.io"
timeout /t 1 /nobreak >nul

:: Inicia o servidor (esta janela fica aberta — nao feche)
echo.
echo  Servidor rodando. Nao feche esta janela.
echo  Feche-a quando terminar de usar o app.
echo.
node server.js
pause
