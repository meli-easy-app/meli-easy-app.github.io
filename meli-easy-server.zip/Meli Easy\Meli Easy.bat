@echo off
powershell -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0MeliEasy.ps1"
