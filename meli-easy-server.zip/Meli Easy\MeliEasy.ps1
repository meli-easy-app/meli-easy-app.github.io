﻿# Meli Easy - Interface de controle do servidor (PowerShell 5.1+)
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$APP_URL   = 'https://meli-easy-app.github.io'
$SERVER_JS = Join-Path $PSScriptRoot 'server.js'
$script:serverProc    = $null
$script:online        = $false
$script:browserOpened = $false

$nodeCmd  = Get-Command node -ErrorAction SilentlyContinue
$NODE_EXE = if ($nodeCmd) { $nodeCmd.Source } else { 'C:\Program Files\nodejs\node.exe' }

# Formulario
$form              = New-Object System.Windows.Forms.Form
$form.Text         = 'Meli Easy'
$form.Size         = New-Object System.Drawing.Size(400, 310)
$form.StartPosition= 'CenterScreen'
$form.BackColor    = [System.Drawing.Color]::FromArgb(20, 21, 43)
$form.ForeColor    = [System.Drawing.Color]::White
$form.FormBorderStyle = 'FixedSingle'
$form.MaximizeBox  = $false

# Titulo
$lblTitle          = New-Object System.Windows.Forms.Label
$lblTitle.Text     = 'Meli Easy'
$lblTitle.Font     = New-Object System.Drawing.Font('Segoe UI', 14, [System.Drawing.FontStyle]::Bold)
$lblTitle.ForeColor= [System.Drawing.Color]::FromArgb(255, 230, 0)
$lblTitle.Location = New-Object System.Drawing.Point(18, 14)
$lblTitle.Size     = New-Object System.Drawing.Size(340, 30)
$form.Controls.Add($lblTitle)

$lblSub2           = New-Object System.Windows.Forms.Label
$lblSub2.Text      = 'Servidor de QR Codes - Onboarding Mercado Livre'
$lblSub2.Font      = New-Object System.Drawing.Font('Segoe UI', 8)
$lblSub2.ForeColor = [System.Drawing.Color]::FromArgb(100, 100, 130)
$lblSub2.Location  = New-Object System.Drawing.Point(19, 44)
$lblSub2.Size      = New-Object System.Drawing.Size(350, 18)
$form.Controls.Add($lblSub2)

# Painel de status
$pnlStatus         = New-Object System.Windows.Forms.Panel
$pnlStatus.Location= New-Object System.Drawing.Point(16, 70)
$pnlStatus.Size    = New-Object System.Drawing.Size(360, 60)
$pnlStatus.BackColor = [System.Drawing.Color]::FromArgb(28, 29, 58)
$form.Controls.Add($pnlStatus)

$lblStatus         = New-Object System.Windows.Forms.Label
$lblStatus.Text    = '... Iniciando servidor...'
$lblStatus.Font    = New-Object System.Drawing.Font('Segoe UI', 10, [System.Drawing.FontStyle]::Bold)
$lblStatus.ForeColor = [System.Drawing.Color]::FromArgb(230, 126, 34)
$lblStatus.Location= New-Object System.Drawing.Point(12, 8)
$lblStatus.Size    = New-Object System.Drawing.Size(336, 22)
$pnlStatus.Controls.Add($lblStatus)

$lblStatusSub      = New-Object System.Windows.Forms.Label
$lblStatusSub.Text = 'Aguarde, subindo o servidor local...'
$lblStatusSub.Font = New-Object System.Drawing.Font('Segoe UI', 8)
$lblStatusSub.ForeColor = [System.Drawing.Color]::FromArgb(122, 123, 149)
$lblStatusSub.Location = New-Object System.Drawing.Point(12, 33)
$lblStatusSub.Size = New-Object System.Drawing.Size(336, 18)
$pnlStatus.Controls.Add($lblStatusSub)

# Botao: Abrir app
$btnOpen           = New-Object System.Windows.Forms.Button
$btnOpen.Text      = 'Abrir Meli Easy no Chrome'
$btnOpen.Font      = New-Object System.Drawing.Font('Segoe UI', 10, [System.Drawing.FontStyle]::Bold)
$btnOpen.Location  = New-Object System.Drawing.Point(16, 144)
$btnOpen.Size      = New-Object System.Drawing.Size(360, 44)
$btnOpen.BackColor = [System.Drawing.Color]::FromArgb(68, 181, 96)
$btnOpen.ForeColor = [System.Drawing.Color]::White
$btnOpen.FlatStyle = 'Flat'
$btnOpen.FlatAppearance.BorderSize = 0
$btnOpen.Enabled   = $false
$btnOpen.Cursor    = [System.Windows.Forms.Cursors]::Hand
$form.Controls.Add($btnOpen)

# Botao: Fechar
$btnStop           = New-Object System.Windows.Forms.Button
$btnStop.Text      = 'Fechar servidor'
$btnStop.Font      = New-Object System.Drawing.Font('Segoe UI', 9, [System.Drawing.FontStyle]::Bold)
$btnStop.Location  = New-Object System.Drawing.Point(16, 200)
$btnStop.Size      = New-Object System.Drawing.Size(360, 38)
$btnStop.BackColor = [System.Drawing.Color]::FromArgb(42, 43, 82)
$btnStop.ForeColor = [System.Drawing.Color]::FromArgb(230, 126, 34)
$btnStop.FlatStyle = 'Flat'
$btnStop.FlatAppearance.BorderSize = 1
$btnStop.FlatAppearance.BorderColor = [System.Drawing.Color]::FromArgb(230, 126, 34)
$btnStop.Cursor    = [System.Windows.Forms.Cursors]::Hand
$form.Controls.Add($btnStop)

$lblNote           = New-Object System.Windows.Forms.Label
$lblNote.Text      = 'Mantenha esta janela aberta enquanto usar o app.'
$lblNote.Font      = New-Object System.Drawing.Font('Segoe UI', 7.5)
$lblNote.ForeColor = [System.Drawing.Color]::FromArgb(80, 80, 110)
$lblNote.Location  = New-Object System.Drawing.Point(19, 250)
$lblNote.Size      = New-Object System.Drawing.Size(350, 18)
$form.Controls.Add($lblNote)

# Funcoes
function UpdateStatus($isOnline) {
    $script:online = $isOnline
    if ($isOnline) {
        $lblStatus.Text      = '[ON]  Servidor ativo'
        $lblStatus.ForeColor = [System.Drawing.Color]::FromArgb(68,181,96)
        $lblStatusSub.Text   = 'localhost:5555  -  Meli Easy conectado'
        $btnOpen.Enabled     = $true
        if (-not $script:browserOpened) {
            $script:browserOpened = $true
            Start-Process $APP_URL
        }
    } else {
        $lblStatus.Text      = '[OFF]  Servidor parado'
        $lblStatus.ForeColor = [System.Drawing.Color]::FromArgb(230,126,34)
        $lblStatusSub.Text   = 'O servidor encerrou. Feche e abra novamente.'
        $btnOpen.Enabled     = $false
    }
}

function StartServer {
    if ($script:serverProc -and -not $script:serverProc.HasExited) { return }
    $script:serverProc = Start-Process $NODE_EXE `
        -ArgumentList "`"$SERVER_JS`"" `
        -WorkingDirectory $PSScriptRoot `
        -WindowStyle Hidden -PassThru
}

function StopServer {
    if ($script:serverProc -and -not $script:serverProc.HasExited) {
        $script:serverProc.Kill()
    }
    $script:serverProc = $null
}

# Timer
$timer          = New-Object System.Windows.Forms.Timer
$timer.Interval = 2000
$timer.Add_Tick({
    try {
        $req = [System.Net.WebRequest]::Create('http://localhost:5555/status')
        $req.Timeout = 1500
        $resp = $req.GetResponse()
        $resp.Close()
        if (-not $script:online) { UpdateStatus $true }
    } catch {
        if ($script:online) { UpdateStatus $false }
    }
})

$btnOpen.Add_Click({ Start-Process $APP_URL })
$btnStop.Add_Click({ $timer.Stop(); StopServer; $form.Close() })
$form.Add_FormClosing({ $timer.Stop(); StopServer })

StartServer
$timer.Start()
[void]$form.ShowDialog()
