/**
 * Meli Easy Server v2.0
 * Servidor local que automatiza o Meli Pass via Chrome + CDP
 * Porta: 5555  |  Uso: node server.js
 */
const puppeteer = require('puppeteer-core');
const http = require('http');
const path = require('path');
const os = require('os');

const CHROME_PATH = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe';
const PROFILE_DIR = path.join(os.homedir(), 'AppData', 'Local', 'MeliEasyServer');
const MELI_URL = 'https://controleacessomlb.providersml.com/AccessControl/Home';
const PORT = 5555;

let browser = null;
let meliPage = null;

// ─── helpers ────────────────────────────────────────────────────────────────
const _w = ms => new Promise(r => setTimeout(r, ms));

async function waitFor(page, fn, args = [], ms = 12000) {
  try {
    await page.waitForFunction(fn, { timeout: ms }, ...args);
    return true;
  } catch (e) { return false; }
}

// ─── inicializa browser ──────────────────────────────────────────────────────
async function ensureBrowser() {
  if (browser) {
    try {
      await meliPage.evaluate(() => true);
      return; // ainda vivo
    } catch (e) {}
  }

  console.log('[MeliEasy] Abrindo Chrome com perfil dedicado...');
  browser = await puppeteer.launch({
    executablePath: CHROME_PATH,
    userDataDir: PROFILE_DIR,
    headless: false,
    args: [
      '--no-first-run',
      '--no-default-browser-check',
      '--disable-extensions',
      '--window-size=1200,800',
      '--window-position=100,100'
    ]
  });

  const pages = await browser.pages();
  meliPage = pages.length > 0 ? pages[0] : await browser.newPage();

  await meliPage.goto(MELI_URL, { waitUntil: 'domcontentloaded', timeout: 30000 });

  console.log('[MeliEasy] Aguardando login no Meli Pass (até 3 minutos)...');
  const logged = await waitFor(meliPage, () =>
    location.hash.startsWith('#/home') ||
    !!document.querySelector('input[ng-model="search.RecordNumber"]'),
    [], 180000
  );

  if (!logged) throw new Error('Timeout de login — faça login no Meli Pass e tente novamente.');
  console.log('[MeliEasy] Conectado ao Meli Pass!');
}

// ─── ir para lista de funcionários ──────────────────────────────────────────
async function goToList() {
  await meliPage.evaluate(() => {
    try {
      const inj = angular.element(document.body).injector();
      inj.get('$location').path('/employee');
      inj.get('$rootScope').$apply();
    } catch (e) { location.hash = '/employee'; }
  });
  const ok = await waitFor(meliPage,
    () => !!document.querySelector('input[ng-model="search.RecordNumber"]'));
  if (!ok) throw new Error('Não abriu a lista de funcionários.');
}

// ─── buscar funcionário por RE ───────────────────────────────────────────────
async function searchEmployee(term) {
  // Preenche o campo de busca
  await meliPage.evaluate(t => {
    const inp = document.querySelector('input[ng-model="search.RecordNumber"]');
    if (!inp) return;
    Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set.call(inp, '');
    ['input','change','keyup'].forEach(ev => inp.dispatchEvent(new Event(ev,{bubbles:true})));
    Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set.call(inp, t);
    ['input','change','keyup'].forEach(ev => inp.dispatchEvent(new Event(ev,{bubbles:true})));
    try { const c = angular.element(inp).controller('ngModel'); if(c){c.$setViewValue(t);c.$render();} } catch(e){}
  }, term);

  await _w(500);

  // Snapshot antes de filtrar
  const snap = await meliPage.evaluate(() => {
    const tbody = document.querySelector('.tableNoBorder tbody, table tbody');
    return tbody ? tbody.innerHTML : '';
  });

  // Clica em filtrar
  await meliPage.evaluate(() => {
    const btn = document.querySelector('input[type="button"][value="filtrar"]') ||
      [...document.querySelectorAll('input[type="button"],button')]
        .find(b => /filtrar|buscar|search/i.test(b.value || b.textContent));
    if (btn) { btn.click(); return; }
    try {
      const inp = document.querySelector('input[ng-model="search.RecordNumber"]');
      const sc = angular.element(inp).scope();
      sc.$apply(() => sc.executeSearch());
    } catch(e) {}
  });

  // Aguarda resultado
  const ok = await waitFor(meliPage, s => {
    const tbody = document.querySelector('.tableNoBorder tbody, table tbody');
    const now = tbody ? tbody.innerHTML : '';
    return now !== s && now.trim().length > 20;
  }, [snap]);

  if (!ok) throw new Error('Funcionário não encontrado: ' + term);
}

// ─── abrir edição ────────────────────────────────────────────────────────────
async function openEdit() {
  await _w(300);
  const hasPencil = await meliPage.evaluate(() => {
    const pencil = document.querySelector('span.icon-pencil.action, span[title="editar"], .icon-pencil');
    if (!pencil) return false;
    try {
      const sc = angular.element(pencil).scope();
      sc.$apply(() => sc.edit(sc.item || sc.employee));
    } catch(e) { pencil.click(); }
    return true;
  });
  if (!hasPencil) throw new Error('Botão editar não encontrado');
  const ok = await waitFor(meliPage, () => !!document.querySelector('input[ng-model="employee.IdentifierQR"]'));
  if (!ok) throw new Error('Página de edição não abriu');
}

// ─── ler QR code ─────────────────────────────────────────────────────────────
async function readQR() {
  await _w(500);
  const qr = await meliPage.evaluate(() => {
    const inp = document.querySelector('input[ng-model="employee.IdentifierQR"]');
    if (!inp) return null;
    let val = inp.value || '';
    if (!val) {
      try { val = angular.element(inp).scope().employee?.IdentifierQR || ''; } catch(e) {}
    }
    return val ? val.trim() : null;
  });
  return qr;
}

// ─── loop principal ──────────────────────────────────────────────────────────
async function fetchQRCodes(batch) {
  await ensureBrowser();
  const results = [];

  for (const collab of batch) {
    const term = (collab.re || collab.cpf || '').replace(/\D/g, '');
    let qrCode = null;

    process.stdout.write(`  [${batch.indexOf(collab)+1}/${batch.length}] ${collab.fname || ''} ${collab.lname || ''} (${term})...`);

    for (let att = 1; att <= 3 && !qrCode; att++) {
      try {
        await goToList();
        await searchEmployee(term);
        await openEdit();
        qrCode = await readQR();
      } catch (e) {
        if (att < 3) { await _w(2000); }
        else console.warn(`\n    ⚠ att=${att}: ${e.message}`);
      }
    }

    console.log(qrCode ? ` ✓ ${qrCode}` : ' ✗ não encontrado');
    results.push({ re: collab.re, cpf: collab.cpf, qrCode: qrCode || null });
  }

  return results;
}

// ─── servidor HTTP ────────────────────────────────────────────────────────────
const server = http.createServer(async (req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') { res.writeHead(204); res.end(); return; }

  const url = new URL(req.url, 'http://localhost');

  // GET /status — verifica se o servidor está vivo
  if (url.pathname === '/status') {
    let browserOk = false;
    if (browser) {
      try { await meliPage.evaluate(() => true); browserOk = true; } catch(e) {}
    }
    res.writeHead(200, {'Content-Type':'application/json'});
    res.end(JSON.stringify({ ok: true, version: '2.0', browserReady: browserOk }));
    return;
  }

  // POST /fetch-qr — recebe batch, retorna QR codes
  if (url.pathname === '/fetch-qr' && req.method === 'POST') {
    let body = '';
    req.on('data', chunk => body += chunk);
    req.on('end', async () => {
      try {
        const { batch } = JSON.parse(body);
        if (!batch?.length) throw new Error('batch vazio');
        console.log(`\n[MeliEasy] Iniciando busca de ${batch.length} colaboradores...`);
        const results = await fetchQRCodes(batch);
        const found = results.filter(r => r.qrCode).length;
        console.log(`\n[MeliEasy] Concluído: ${found}/${batch.length} QR codes encontrados.`);
        res.writeHead(200, {'Content-Type':'application/json'});
        res.end(JSON.stringify({ ok: true, results }));
      } catch (e) {
        console.error('\n[MeliEasy] Erro:', e.message);
        res.writeHead(500, {'Content-Type':'application/json'});
        res.end(JSON.stringify({ ok: false, error: e.message }));
      }
    });
    return;
  }

  res.writeHead(404);
  res.end('Not found');
});

server.listen(PORT, '127.0.0.1', () => {
  console.log('╔═══════════════════════════════════════════╗');
  console.log('║     🔖 Meli Easy Server v2.0              ║');
  console.log(`║     Rodando em http://localhost:${PORT}     ║`);
  console.log('╠═══════════════════════════════════════════╣');
  console.log('║  1. Chrome vai abrir automaticamente       ║');
  console.log('║  2. Faça login no Meli Pass (1ª vez)       ║');
  console.log('║  3. Use o botão no app Meli Easy           ║');
  console.log('╚═══════════════════════════════════════════╝');
});

process.on('SIGINT', async () => {
  console.log('\n[MeliEasy] Encerrando...');
  if (browser) await browser.close().catch(()=>{});
  server.close();
  process.exit(0);
});
