// Meli Easy — QR Pass Extension background service worker
'use strict';

const MELI_URL = 'https://controleacessomlb.providersml.com/AccessControl/Home';

const state = {
  webAppTabId: null,
  meliTabId: null,
  collaborators: [],
  running: false,
  cancelled: false
};

// ── Receive messages from content_relay.js (which got them from the web page) ─
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || !msg.__meliEasy) return;
  state.webAppTabId = sender.tab?.id ?? null;

  (async () => {
    try {
      switch (msg.action) {
        case 'ping':
          sendResponse({ __meliEasyResp: true, action: 'pong' });
          break;

        case 'start': {
          if (state.running) { sendResponse({ ok: false, error: 'already_running' }); return; }
          state.collaborators = msg.collaborators || [];
          state.running = true;
          state.cancelled = false;

          const tab = await chrome.tabs.create({ url: MELI_URL });
          state.meliTabId = tab.id;

          const onUpdate = (tabId, info) => {
            if (tabId !== state.meliTabId || info.status !== 'complete') return;
            chrome.tabs.onUpdated.removeListener(onUpdate);
            // Give Angular 1.5s to render before prompting login
            setTimeout(() => notifyWebApp({ action: 'login_prompt' }), 1500);
          };
          chrome.tabs.onUpdated.addListener(onUpdate);
          sendResponse({ ok: true });
          break;
        }

        case 'confirm_login':
          sendResponse({ ok: true });
          runAutomation();
          break;

        case 'cancel':
          state.cancelled = true;
          state.running = false;
          if (state.meliTabId) {
            chrome.tabs.remove(state.meliTabId).catch(() => {});
            state.meliTabId = null;
          }
          sendResponse({ ok: true });
          break;

        default:
          sendResponse({ ok: false, error: 'unknown_action' });
      }
    } catch (e) {
      sendResponse({ ok: false, error: e.message });
    }
  })();
  return true; // keep channel open for async response
});

// ── Send a message to the web app tab via its content script ─────────────────
function notifyWebApp(data) {
  if (state.webAppTabId == null) return;
  chrome.tabs.sendMessage(state.webAppTabId, Object.assign({}, data, { __meliEasyPush: true }))
    .catch(() => {});
}

// ── Navigate Meli Pass tab to home and wait for Angular to render ─────────────
async function navigateToHome() {
  if (!state.meliTabId) return;
  await chrome.tabs.update(state.meliTabId, { url: MELI_URL });
  await new Promise(resolve => {
    const onUpdate = (tabId, info) => {
      if (tabId !== state.meliTabId || info.status !== 'complete') return;
      chrome.tabs.onUpdated.removeListener(onUpdate);
      setTimeout(resolve, 1200);
    };
    chrome.tabs.onUpdated.addListener(onUpdate);
  });
}

// ── Inject and run one automation step in the Meli Pass tab ─────────────────
async function execStep(step, term) {
  if (!state.meliTabId) return { error: 'tab_closed' };
  try {
    const results = await chrome.scripting.executeScript({
      target: { tabId: state.meliTabId },
      func: meliStep,
      args: [step, term || null],
      world: 'MAIN'
    });
    return results?.[0]?.result ?? { error: 'no_result' };
  } catch (e) {
    return { error: e.message };
  }
}

// ── Main automation loop ──────────────────────────────────────────────────────
async function runAutomation() {
  const total = state.collaborators.length;
  const STEP_LABELS = ['', 'Configurações…', 'Funcionários…', 'Abrindo filtro…', 'Buscando RE…', 'Abrindo ficha…', 'Lendo QR…'];

  for (let i = 0; i < total; i++) {
    if (state.cancelled) break;

    const d = state.collaborators[i];
    const term = (d.re || d.cpf || '').replace(/\D/g, '');
    const fullName = `${d.fname || ''} ${d.lname || ''}`.trim();

    notifyWebApp({ action: 'progress', index: i, total, name: fullName });

    let qrCode = null;

    for (let attempt = 1; attempt <= 3; attempt++) {
      if (state.cancelled) break;

      await navigateToHome();
      let stepFailed = false;

      for (let s = 1; s <= 6; s++) {
        if (state.cancelled) break;
        notifyWebApp({ action: 'step', index: i, step: s, status: 'running', label: STEP_LABELS[s] });

        const res = await execStep(s, s === 4 ? term : null);

        if (res?.error) {
          notifyWebApp({ action: 'step', index: i, step: s, status: 'error', error: res.error });
          stepFailed = true;
          break;
        }
        if (s === 6 && res?.qrCode) qrCode = res.qrCode;
        notifyWebApp({ action: 'step', index: i, step: s, status: 'done' });
      }

      if (qrCode) break;
      if (!stepFailed) break;
      if (attempt < 3 && !state.cancelled) {
        notifyWebApp({ action: 'retry', index: i, attempt });
        await new Promise(r => setTimeout(r, 3000));
      }
    }

    if (qrCode) {
      notifyWebApp({ action: 'qr_found', index: i, re: d.re, cpf: d.cpf, qrCode });
    } else {
      notifyWebApp({ action: 'qr_not_found', index: i, re: d.re, cpf: d.cpf });
    }
  }

  state.running = false;
  notifyWebApp({ action: 'complete' });
  if (state.meliTabId) {
    chrome.tabs.remove(state.meliTabId).catch(() => {});
    state.meliTabId = null;
  }
}

// ── This function is SERIALIZED and injected into the Meli Pass page ─────────
// It must be 100% self-contained — no closure variables allowed.
function meliStep(step, term) {
  const _w = ms => new Promise(r => setTimeout(r, ms));

  function _find(text) {
    const all = Array.from(document.querySelectorAll('a,button,li,span,div,p,td'));
    return all.find(e => e.textContent.trim() === text)
        || all.find(e => e.textContent.trim().includes(text))
        || all.find(e => (e.getAttribute('title') || '').includes(text));
  }
  function _clickable(el) {
    if (!el) return null;
    let cur = el;
    while (cur && cur !== document.body) {
      if (cur.tagName === 'A' || cur.tagName === 'BUTTON' ||
          cur.getAttribute('ng-click') || cur.getAttribute('ui-sref') || cur.getAttribute('href'))
        return cur;
      cur = cur.parentElement;
    }
    return el;
  }
  async function _waitCond(fn, ms) {
    const t0 = Date.now();
    while (Date.now() - t0 < (ms || 10000)) {
      try { if (fn()) return true; } catch (_) {}
      await _w(400);
    }
    return false;
  }
  function _setVal(inp, val) {
    try { const c = angular.element(inp).controller('ngModel'); if (c) { c.$setViewValue(val); c.$render(); } } catch (_) {}
    try {
      Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set.call(inp, val);
      ['input', 'change', 'keyup'].forEach(ev => inp.dispatchEvent(new Event(ev, { bubbles: true })));
    } catch (_) {}
    try {
      const m = inp.getAttribute('ng-model');
      if (m) { const sc = angular.element(inp).scope(); const p = m.split('.'); let o = sc; for (let i = 0; i < p.length - 1; i++) o = o[p[i]]; o[p[p.length - 1]] = val; sc.$apply(); }
    } catch (_) {}
  }
  const _norm = s => (s || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().trim();
  const _dispara = el => {
    if (!el) return;
    ['mouseenter', 'mouseover', 'mousedown', 'mouseup', 'click'].forEach(ev =>
      el.dispatchEvent(new MouseEvent(ev, { bubbles: true, cancelable: true, view: window }))
    );
  };
  const _pt = () => document.body.innerText.substring(0, 700);
  const _inps = () => Array.from(document.querySelectorAll('input')).slice(0, 15)
    .map(i => ({ id: i.id, ng: i.getAttribute('ng-model'), ph: i.placeholder, val: (i.value || '').substring(0, 30) }));

  // Step 1: Configurações
  if (step === 1) {
    return new Promise(async resolve => {
      const urlInicio = location.href;
      let navegou = false;
      try {
        const inj = angular.element(document.body).injector();
        const $state = inj.get('$state');
        const alvo = $state.get().map(s => s.name).find(s => /configur/i.test(_norm(s)));
        if (alvo) { $state.go(alvo); navegou = true; }
      } catch (_) {}
      if (!navegou) {
        const tile = Array.from(document.querySelectorAll('[ng-click],[ui-sref],a[href]'))
          .find(el => _norm(el.textContent).includes('configura'));
        if (tile) {
          try { const ngc = tile.getAttribute('ng-click'); if (ngc) { angular.element(tile).scope().$apply(sc => sc.$eval(ngc)); navegou = true; } } catch (_) {}
          const icone = tile.querySelector('img,svg,i,[class*="icon"],[class*="circle"]') || tile.firstElementChild;
          _dispara(icone || tile);
          if (!navegou) { _dispara(tile); navegou = true; }
        }
      }
      if (!navegou) { const el = _clickable(_find('Configurações')); if (el) { _dispara(el); navegou = true; } }
      if (!navegou) return resolve({ error: 'config_nao_encontrado', page: _pt() });
      const ok = await _waitCond(() => location.href !== urlInicio && /funcionári|funcionario/i.test(document.body.innerText), 12000);
      resolve(ok ? { ok: true } : { error: 'config_timeout', page: _pt() });
    });
  }

  // Step 2: Funcionários
  if (step === 2) {
    return new Promise(async resolve => {
      const urlInicio = location.href;
      let navegou = false;
      try {
        const inj = angular.element(document.body).injector();
        const $state = inj.get('$state');
        const alvo = $state.get().map(s => s.name).find(s => /funcionar/i.test(s));
        if (alvo) { $state.go(alvo); navegou = true; }
      } catch (_) {}
      if (!navegou) {
        const texto = _find('Funcionários') || _find('Funcionarios');
        let cur = texto;
        while (cur && cur !== document.body) {
          const ngc = cur.getAttribute('ng-click');
          if (ngc) { try { angular.element(cur).scope().$apply(sc => sc.$eval(ngc)); navegou = true; } catch (_) { cur.click(); navegou = true; } break; }
          cur = cur.parentElement;
        }
        if (!navegou && texto) { const el = _clickable(texto); if (el) { el.click(); navegou = true; } }
      }
      if (!navegou) return resolve({ error: 'funcionarios_nao_encontrado', page: _pt() });
      const ok = await _waitCond(() =>
        location.href !== urlInicio || !!(document.querySelector('table tbody tr,[ng-repeat],.fa-search,.glyphicon-search') && document.body.innerText.length > 200)
      , 10000);
      resolve(ok ? { ok: true } : { error: 'func_timeout', page: _pt() });
    });
  }

  // Step 3: Abrir filtro
  if (step === 3) {
    return new Promise(async resolve => {
      await _w(500);
      if (document.querySelector('input[ng-model*="egistro"],input[ng-model*="Registro"],input[ng-model*="registro"]') ||
          Array.from(document.querySelectorAll('label,.control-label')).some(n => /registro/i.test(n.textContent)))
        return resolve({ ok: true, via: 'already' });
      const lupa =
        document.querySelector('[ng-click*="pesquis"],[ng-click*="search"],[ng-click*="filter"],[ng-click*="filtro"]') ||
        document.querySelector('.fa-search')?.closest('a,button,[ng-click]') ||
        document.querySelector('.glyphicon-search')?.closest('a,button') ||
        Array.from(document.querySelectorAll('a,button')).find(e => /pesquisar|filtrar|buscar|search/i.test(e.textContent));
      if (!lupa) return resolve({ error: 'lupa_nao_encontrada', page: _pt() });
      lupa.click();
      const ok = await _waitCond(() =>
        !!(document.querySelector('input[ng-model*="egistro"],input[ng-model*="Registro"],input[ng-model*="registro"]') || document.querySelector('input:not([type="hidden"])'))
      , 7000);
      resolve(ok ? { ok: true } : { error: 'filtro_timeout', inputs: _inps() });
    });
  }

  // Step 4: Preencher Registro e filtrar
  if (step === 4) {
    const t = (term || '').replace(/\D/g, '');
    return new Promise(async resolve => {
      await _w(300);
      let inp = document.querySelector('input[ng-model*="egistro"],input[ng-model*="Registro"],input[ng-model*="registro"]');
      if (!inp) {
        for (const lbl of document.querySelectorAll('label,.control-label,td,th,span,div')) {
          const txt = (lbl.textContent || '').trim().replace(/:+$/, '');
          if (!/^registro$/i.test(txt)) continue;
          const fid = lbl.getAttribute('for'); if (fid) { inp = document.getElementById(fid); if (inp) break; }
          const col = lbl.closest('div.col,div.form-group,[class*="col-"],.form-group'); if (col) { inp = col.querySelector('input'); if (inp) break; }
          if (lbl.tagName === 'TD') { const nxt = lbl.nextElementSibling; if (nxt) { inp = nxt.tagName === 'INPUT' ? nxt : nxt.querySelector('input'); if (inp) break; } }
          let s = lbl.nextElementSibling; while (s && s.tagName !== 'INPUT') s = s.nextElementSibling; if (s) { inp = s; break; }
        }
      }
      if (!inp) {
        for (const el of document.querySelectorAll('input[type="text"],input:not([type])')) {
          const par = el.closest('div,td,.form-group'); if (par) { const lbl = par.querySelector('label,.control-label'); if (lbl && /registro/i.test(lbl.textContent)) { inp = el; break; } }
          let prev = el.previousElementSibling; while (prev) { if (/registro/i.test(prev.textContent)) { inp = el; break; } prev = prev.previousElementSibling; }
          if (inp) break;
        }
      }
      if (!inp) return resolve({ error: 'campo_registro_nao_encontrado', inputs: _inps() });
      inp.focus(); _setVal(inp, t); await _w(700);
      const snapTarget = document.querySelector('table tbody,tbody,[ng-repeat]');
      const snapAntes = snapTarget ? snapTarget.innerHTML : document.body.innerHTML.substring(0, 8000);
      const clicar = el => { if (el) el.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, view: window })); };
      const todosBtn = Array.from(document.querySelectorAll('button,input[type="submit"],input[type="button"]'));
      const alvo = todosBtn.find(e => /^filtrar$/i.test((e.textContent || e.value || '').trim()))
        || todosBtn.find(e => /filtrar|buscar|pesquisar/i.test((e.textContent || e.value || '').trim()))
        || document.querySelector('form [ng-click*="filtrar"],form [ng-click*="buscar"],form [ng-click*="pesquis"]')
        || document.querySelector('[ng-click*="filtrar"],[ng-click*="buscar"],[ng-click*="pesquis"]');
      let clicou = false;
      if (alvo) { clicar(alvo); clicou = true; }
      if (!clicou) { const form = document.querySelector('form[ng-submit],form'); if (form) { const ngSub = form.getAttribute('ng-submit'); if (ngSub) { try { angular.element(form).scope().$apply(sc => sc.$eval(ngSub)); clicou = true; } catch (_) {} } if (!clicou) { form.dispatchEvent(new Event('submit', { bubbles: true })); clicou = true; } } }
      if (!clicou) return resolve({ error: 'botao_filtrar_nao_encontrado' });
      const ok = await _waitCond(() => { const now = (document.querySelector('table tbody,tbody,[ng-repeat]') || {}).innerHTML || document.body.innerHTML.substring(0, 8000); return now !== snapAntes && now.trim().length > 10; }, 12000);
      resolve(ok ? { ok: true } : { error: 'busca_sem_resultado', page: _pt() });
    });
  }

  // Step 5: Abrir ficha
  if (step === 5) {
    return new Promise(async resolve => {
      await _w(300);
      let el = document.querySelector('a[ng-click*="edit"],button[ng-click*="edit"],a[ng-click*="detalhe"],button[ng-click*="detalhe"],a[ui-sref*="edit"],[title*="ditar"],[title*="etalhe"]');
      if (!el) { const icon = document.querySelector('.fa-pencil,.fa-edit,.fa-pencil-alt,.glyphicon-pencil,.fa-eye,.fa-search-plus'); if (icon) el = icon.closest('a,button') || icon; }
      if (!el) {
        const rows = Array.from(document.querySelectorAll('table tbody tr[ng-repeat],table tbody tr,li[ng-repeat],div[ng-repeat]')).filter(r => r.textContent.trim().length > 3);
        if (rows.length) { const btns = Array.from(rows[0].querySelectorAll('a,button')); el = btns.find(b => /editar|edit|detalhe|ver|view|ficha/i.test(b.textContent + (b.getAttribute('ng-click') || '') + (b.className || ''))) || btns[btns.length - 1] || null; }
      }
      if (!el) return resolve({ error: 'lapis_nao_encontrado' });
      el.click();
      const ok = await _waitCond(() =>
        Array.from(document.querySelectorAll('label,span,.control-label,th,td')).some(n => /qr.?code/i.test(n.textContent)) || document.querySelector('form input,.form-control') !== null
      , 10000);
      resolve(ok ? { ok: true } : { error: 'ficha_timeout', page: _pt() });
    });
  }

  // Step 6: Ler QR Code
  if (step === 6) {
    return new Promise(async resolve => {
      await _w(500);
      for (const node of document.querySelectorAll('label,span,td,.control-label,th,div,p')) {
        if (!/qr.?code/i.test(node.textContent.trim())) continue;
        const fid = node.getAttribute && node.getAttribute('for');
        let inp = fid ? document.getElementById(fid) : null;
        if (!inp) { let s = node.nextElementSibling; while (s && s.tagName !== 'INPUT' && s.tagName !== 'SPAN' && s.tagName !== 'P') s = s.nextElementSibling; inp = s; }
        if (!inp) { const p = node.closest('div,tr,.form-group,.row,li'); if (p) inp = p.querySelector('input') || p; }
        const val = (inp && (inp.value || inp.textContent || '')).trim();
        if (val && /\d/.test(val)) return resolve({ qrCode: val });
      }
      for (const sel of ['input[ng-model*="QrCode"]', 'input[ng-model*="qrCode"]', 'input[ng-model*="qr_code"]', 'input[id*="qr" i]']) {
        const el = document.querySelector(sel); if (el && el.value) return resolve({ qrCode: el.value.trim() });
      }
      const cands = Array.from(document.querySelectorAll('input[readonly],input[disabled],input')).filter(i => i.value && /^\d{4,}$/.test(i.value.trim()));
      if (cands.length) return resolve({ qrCode: cands[0].value.trim() });
      resolve({ error: 'qr_nao_encontrado', page: _pt() });
    });
  }

  return Promise.resolve({ error: 'step_invalido' });
}
